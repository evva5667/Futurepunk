import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import { questions, type Answers } from "./ReconnectManager";

interface QuestionCarouselProps {
  onAnswer: (questionId: string, optionId: string) => void;
  answers: Answers;
  onComplete: () => void;
  currentSeat: "1" | "2";
}

export function QuestionCarousel({
  onAnswer,
  answers,
  onComplete,
  currentSeat,
}: QuestionCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const autoAdvanceTimer = useRef<NodeJS.Timeout | null>(null);

  const currentQuestion = questions[currentIndex];
  const isLastQuestion = currentIndex === questions.length - 1;

  // Load saved answer when question changes
  useEffect(() => {
    const savedAnswer = answers[currentQuestion.id];
    setSelectedOption(savedAnswer || null);
  }, [currentIndex, answers, currentQuestion.id]);

  // Handle option selection
  const handleSelectOption = (optionId: string) => {
    setSelectedOption(optionId);
    onAnswer(currentQuestion.id, optionId);

    // Clear existing timer
    if (autoAdvanceTimer.current) {
      clearTimeout(autoAdvanceTimer.current);
    }

    // Auto-advance after 300ms (unless last question)
    if (!isLastQuestion) {
      autoAdvanceTimer.current = setTimeout(() => {
        setCurrentIndex((prev) => Math.min(prev + 1, questions.length - 1));
      }, 300);
    }
  };

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (autoAdvanceTimer.current) {
        clearTimeout(autoAdvanceTimer.current);
      }
    };
  }, []);

  // Navigate to previous question
  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  // Navigate to next question
  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Progress Indicator */}
      <div className="text-center mb-6">
        <p className="text-sm text-muted-foreground">
          Question {currentIndex + 1} of {questions.length}
        </p>
        <div className="mt-2 w-full bg-secondary/20 rounded-full h-1.5">
          <motion.div
            className="bg-gradient-to-r from-[#ffb380] to-[#ff8a5b] h-full rounded-full"
            initial={{ width: 0 }}
            animate={{
              width: `${((currentIndex + 1) / questions.length) * 100}%`,
            }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Question Card with Carousel Effect */}
      <div className="relative min-h-[320px] mb-6">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, x: 100, scale: 0.9, filter: "blur(8px)" }}
            animate={{ opacity: 1, x: 0, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, x: -100, scale: 0.9, filter: "blur(8px)" }}
            transition={{
              duration: 0.6,
              ease: [0.4, 0.0, 0.2, 1],
            }}
            className="absolute inset-0"
          >
            <div className="bg-card border border-border rounded-xl p-8 shadow-lg">
              {/* Question Text */}
              <h3 className="mb-6 text-center">{currentQuestion.text}</h3>

              {/* Answer Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentQuestion.options.map((option) => {
                  const isSelected = selectedOption === option.id;

                  return (
                    <motion.button
                      key={option.id}
                      onClick={() => handleSelectOption(option.id)}
                      className={`
                        relative p-4 rounded-lg text-left transition-all
                        border-2
                        ${
                          isSelected
                            ? "border-[#ff8a5b] bg-gradient-to-br from-[#ffd7b0] to-[#fff2ea] shadow-[0_6px_16px_rgba(255,138,91,0.2)]"
                            : "border-border bg-card hover:border-[#ffb380]/50 hover:shadow-md"
                        }
                      `}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span
                        className={
                          isSelected ? "text-foreground" : "text-foreground"
                        }
                      >
                        {option.text}
                      </span>

                      {/* Selection indicator */}
                      {isSelected && (
                        <motion.div
                          layoutId="selection-indicator"
                          className="absolute top-2 right-2 w-5 h-5 bg-[#ff8a5b] rounded-full flex items-center justify-center"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", stiffness: 500 }}
                        >
                          <svg
                            className="w-3 h-3 text-white"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={3}
                              d="M5 13l4 4L19 7"
                            />
                          </svg>
                        </motion.div>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={handlePrevious}
          disabled={currentIndex === 0}
        >
          ← Previous
        </Button>

        <div className="flex items-center gap-2">
          {/* Quick navigation dots */}
          <div className="flex gap-1.5">
            {questions.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`
                  w-2 h-2 rounded-full transition-all
                  ${
                    idx === currentIndex
                      ? "bg-[#ff8a5b] w-6"
                      : answers[questions[idx].id]
                      ? "bg-[#ffb380]"
                      : "bg-secondary"
                  }
                `}
              />
            ))}
          </div>
        </div>

        {isLastQuestion ? (
          <Button
            onClick={onComplete}
            disabled={!selectedOption}
            className="bg-gradient-to-r from-[#ffb380] to-[#ff8a5b] hover:shadow-lg"
          >
            {currentSeat === "1" ? "Save & Share →" : "Finish →"}
          </Button>
        ) : (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNext}
            disabled={currentIndex === questions.length - 1}
          >
            Next →
          </Button>
        )}
      </div>
    </div>
  );
}
