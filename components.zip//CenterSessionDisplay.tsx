import { motion, AnimatePresence } from "framer-motion";
import { Users, CheckCircle2 } from "lucide-react";

interface CenterSessionDisplayProps {
  sessionCode: string | null;
  currentSeat: "1" | "2" | null;
  progress: number;
  totalQuestions: number;
  size: number;
}

export function CenterSessionDisplay({
  sessionCode,
  currentSeat,
  progress,
  totalQuestions,
  size,
}: CenterSessionDisplayProps) {
  if (!sessionCode) return null;

  const isComplete = progress === totalQuestions;

  return (
    <div
      className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"
      style={{
        width: size,
        height: size,
      }}
    >
      <div className="flex flex-col items-center justify-center h-full">
        <AnimatePresence mode="wait">
          {isComplete ? (
            <motion.div
              key="complete"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 20 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="bg-gradient-to-br from-[#ffb380] to-[#ff8a5b] rounded-full p-4 shadow-2xl">
                <CheckCircle2 className="w-8 h-8 text-white drop-shadow-lg" />
              </div>
              <div className="text-center">
                <p className="text-sm text-white drop-shadow-lg">All questions answered!</p>
                {currentSeat === "1" && (
                  <p className="text-xs text-white/80 mt-1 drop-shadow">
                    Tap to share with Person B
                  </p>
                )}
                {currentSeat === "2" && (
                  <p className="text-xs text-white/80 mt-1 drop-shadow">
                    Tap to see results
                  </p>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="active"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 20 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="bg-black/90 backdrop-blur-md border border-white/20 rounded-full px-4 py-2 shadow-lg">
                <p className="text-sm">
                  <span className="text-white/70">Session:</span>{" "}
                  <span className="font-mono text-white">{sessionCode}</span>
                </p>
              </div>
              
              <div className="flex items-center gap-2 bg-black/90 backdrop-blur-md border border-white/20 rounded-full px-4 py-2 shadow-lg">
                <Users className="w-4 h-4 text-white/70" />
                <p className="text-sm">
                  <span className="text-white/70">Seat:</span>{" "}
                  <span className="text-[#ff8a5b] font-bold">{currentSeat}</span>
                </p>
              </div>

              <div className="bg-black/90 backdrop-blur-md border border-white/20 rounded-full px-4 py-2 shadow-lg">
                <p className="text-sm text-white/70">
                  {progress}/{totalQuestions} answered
                </p>
              </div>

              <p className="text-xs text-white/70 mt-2">
                Tap to continue
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
