import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { QRCodeGenerator } from "./QRCodeGenerator";
import { Copy, QrCode, ExternalLink, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface StartSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartSession: () => { code: string; url: string };
  onJoinSession: (input: string) => boolean;
}

export function StartSheet({
  open,
  onOpenChange,
  onStartSession,
  onJoinSession,
}: StartSheetProps) {
  const [joinInput, setJoinInput] = useState("");
  const [sessionInfo, setSessionInfo] = useState<{
    code: string;
    url: string;
  } | null>(null);
  const [showQR, setShowQR] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleStartSession = () => {
    const info = onStartSession();
    setSessionInfo(info);
    // Don't close sheet, show session info instead
  };

  const handleJoinSession = () => {
    const success = onJoinSession(joinInput);
    if (success) {
      onOpenChange(false);
      setJoinInput("");
    }
  };

  const handleCopyLink = () => {
    if (sessionInfo) {
      navigator.clipboard.writeText(sessionInfo.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleOpenLink = () => {
    if (sessionInfo) {
      window.open(sessionInfo.url, "_blank");
    }
  };

  // Reset session info when sheet closes
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setSessionInfo(null);
      setShowQR(false);
      setCopied(false);
      setJoinInput("");
    }
    onOpenChange(newOpen);
  };

  return (
    <Sheet open={open} onOpenChange={handleOpenChange}>
      <SheetContent
        side="bottom"
        className="h-[85vh] flex flex-col bg-background/95 backdrop-blur-xl"
      >
        <SheetHeader>
          <SheetTitle>Reconnect Booth</SheetTitle>
          <SheetDescription>
            UAE 2050 — Answer quick questions to discover your compatibility
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto py-6">
          <div className="max-w-md mx-auto space-y-6">
            <AnimatePresence mode="wait">
              {!sessionInfo ? (
                <motion.div
                  key="start-options"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  {/* Start New Session */}
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground text-center">
                      Choose how you want to join:
                    </p>
                    <Button
                      onClick={handleStartSession}
                      className="w-full h-auto py-4 bg-gradient-to-r from-[#ffb380] to-[#ff8a5b] hover:shadow-lg"
                      size="lg"
                    >
                      Start a new session (Seat 1)
                    </Button>
                  </div>

                  {/* Divider */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-border" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">
                        or
                      </span>
                    </div>
                  </div>

                  {/* Join Existing Session */}
                  <div className="space-y-3">
                    <Input
                      placeholder="Paste link or code..."
                      value={joinInput}
                      onChange={(e) => setJoinInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && joinInput.trim()) {
                          handleJoinSession();
                        }
                      }}
                    />
                    <Button
                      onClick={handleJoinSession}
                      disabled={!joinInput.trim()}
                      variant="secondary"
                      className="w-full"
                      size="lg"
                    >
                      Join (Seat 2)
                    </Button>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="session-info"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-4"
                >
                  {/* Session Info Card */}
                  <div className="bg-card border border-border rounded-xl p-6 space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">
                        Session Code
                      </p>
                      <p className="text-2xl font-mono tracking-wider">
                        {sessionInfo.code}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-border">
                      <p className="text-sm mb-3">
                        <strong>Person A (You):</strong> You can start answering
                        questions now!
                      </p>
                      <p className="text-sm text-muted-foreground mb-4">
                        Share this join link with Person B so they can answer
                        the same questions:
                      </p>

                      {/* Link Actions */}
                      <div className="space-y-2">
                        <div className="flex gap-2">
                          <Button
                            onClick={handleCopyLink}
                            variant="secondary"
                            size="sm"
                            className="flex-1"
                          >
                            {copied ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copied!
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copy Link
                              </>
                            )}
                          </Button>
                          <Button
                            onClick={() => setShowQR(!showQR)}
                            variant="secondary"
                            size="sm"
                          >
                            <QrCode className="w-4 h-4 mr-2" />
                            {showQR ? "Hide QR" : "Show QR"}
                          </Button>
                          <Button
                            onClick={handleOpenLink}
                            variant="secondary"
                            size="sm"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* QR Code */}
                        <AnimatePresence>
                          {showQR && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="pt-4"
                            >
                              <QRCodeGenerator text={sessionInfo.url} size={200} />
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                  </div>

                  {/* Continue Button */}
                  <Button
                    onClick={() => handleOpenChange(false)}
                    className="w-full bg-gradient-to-r from-[#ffb380] to-[#ff8a5b]"
                    size="lg"
                  >
                    Continue to Questions
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
