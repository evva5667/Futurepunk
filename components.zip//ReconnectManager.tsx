import { useState, useEffect } from "react";

// Question and answer type definitions
export interface QuestionOption {
  id: string;
  text: string;
  type: 1 | 2 | 3 | 4; // Personality types
}

export interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

export interface Answers {
  [questionId: string]: string; // questionId -> optionId
}

export interface SessionData {
  seat1?: Answers;
  seat2?: Answers;
}

// Questions database
export const questions: Question[] = [
  {
    id: "q1",
    text: "Your ideal weekday evening involves:",
    options: [
      { id: "q1a", text: "Quiet time at home with a book or show", type: 1 },
      { id: "q1b", text: "Video call with a friend", type: 2 },
      { id: "q1c", text: "Exploring a new cafe or walking route", type: 3 },
      { id: "q1d", text: "Group hangout or community event", type: 4 },
    ],
  },
  {
    id: "q2",
    text: "When you meet someone new, you usually:",
    options: [
      { id: "q2a", text: "Observe and listen more than talk", type: 1 },
      { id: "q2b", text: "Ask a few questions to get a feel for them", type: 2 },
      { id: "q2c", text: "Share a story or idea to break the ice", type: 3 },
      { id: "q2d", text: "Jump right into a lively conversation", type: 4 },
    ],
  },
  {
    id: "q3",
    text: "You'd describe your social energy as:",
    options: [
      { id: "q3a", text: "Recharged by alone time", type: 1 },
      { id: "q3b", text: "Balanced — depends on the day", type: 2 },
      { id: "q3c", text: "Energized by interesting people", type: 3 },
      { id: "q3d", text: "Thrives in groups and events", type: 4 },
    ],
  },
  {
    id: "q4",
    text: "Your weekend plans are often:",
    options: [
      { id: "q4a", text: "Low-key, maybe one small plan", type: 1 },
      { id: "q4b", text: "One social thing, one solo thing", type: 2 },
      { id: "q4c", text: "Trying something new or spontaneous", type: 3 },
      { id: "q4d", text: "Full calendar of meetups and activities", type: 4 },
    ],
  },
  {
    id: "q5",
    text: "You prefer conversations that are:",
    options: [
      { id: "q5a", text: "Deep and thoughtful", type: 1 },
      { id: "q5b", text: "A mix of light and meaningful", type: 2 },
      { id: "q5c", text: "Curious and exploratory", type: 3 },
      { id: "q5d", text: "Fast-paced and fun", type: 4 },
    ],
  },
  {
    id: "q6",
    text: "When planning an outing with someone:",
    options: [
      { id: "q6a", text: "You prefer they suggest a quiet spot", type: 1 },
      { id: "q6b", text: "You collaborate on a place you'll both enjoy", type: 2 },
      { id: "q6c", text: "You suggest something new or unique", type: 3 },
      { id: "q6d", text: "You pick a lively, popular spot", type: 4 },
    ],
  },
  {
    id: "q7",
    text: "Your approach to making friends is:",
    options: [
      { id: "q7a", text: "Slow and selective", type: 1 },
      { id: "q7b", text: "Open but intentional", type: 2 },
      { id: "q7c", text: "Curious and exploratory", type: 3 },
      { id: "q7d", text: "Outgoing and inclusive", type: 4 },
    ],
  },
  {
    id: "q8",
    text: "You feel most connected when:",
    options: [
      { id: "q8a", text: "Having meaningful one-on-one time", type: 1 },
      { id: "q8b", text: "Doing something together (like a project)", type: 2 },
      { id: "q8c", text: "Exploring ideas or places together", type: 3 },
      { id: "q8d", text: "Sharing experiences in a group", type: 4 },
    ],
  },
  {
    id: "q9",
    text: "Your texting style is:",
    options: [
      { id: "q9a", text: "Thoughtful replies, sometimes delayed", type: 1 },
      { id: "q9b", text: "Depends on my mood and the topic", type: 2 },
      { id: "q9c", text: "Quick responses with lots of ideas", type: 3 },
      { id: "q9d", text: "Constant back-and-forth, lots of emojis", type: 4 },
    ],
  },
  {
    id: "q10",
    text: "You'd describe your vibe as:",
    options: [
      { id: "q10a", text: "Calm and introspective", type: 1 },
      { id: "q10b", text: "Adaptable and easygoing", type: 2 },
      { id: "q10c", text: "Creative and curious", type: 3 },
      { id: "q10d", text: "Energetic and outgoing", type: 4 },
    ],
  },
];

// Activity suggestions based on dominant type
export const activitySuggestions: { [key: number]: string[] } = {
  1: [
    "Coffee and deep conversation at a quiet cafe",
    "Museum or gallery visit",
    "Nature walk or park visit",
  ],
  2: [
    "Collaborative cooking or art class",
    "Board game cafe",
    "Casual lunch and explore a neighborhood",
  ],
  3: [
    "Art/cook collab or creative workshop",
    "City exploration or new restaurant",
    "Creative jam session or maker space",
  ],
  4: [
    "Group outing (trivia, sports, concert)",
    "Community event or festival",
    "Active adventure (hiking, sports, dancing)",
  ],
};

// Encoding and decoding utilities
export function encodeState(data: any): string {
  const json = JSON.stringify(data);
  const base64 = btoa(json);
  // Make URL-safe
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}

export function decodeState(encoded: string): any {
  try {
    // Restore standard base64
    let base64 = encoded.replace(/-/g, "+").replace(/_/g, "/");
    // Pad with = until length is multiple of 4
    while (base64.length % 4) {
      base64 += "=";
    }
    const json = atob(base64);
    return JSON.parse(json);
  } catch (error) {
    console.error("Failed to decode state:", error);
    return null;
  }
}

// Generate session code
export function generateSessionCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Session storage helpers
export function saveSession(code: string, data: SessionData): void {
  sessionStorage.setItem(`reconnect_session_${code}`, JSON.stringify(data));
}

export function loadSession(code: string): SessionData | null {
  const data = sessionStorage.getItem(`reconnect_session_${code}`);
  return data ? JSON.parse(data) : null;
}

// Compatibility calculation
export function calculateCompatibility(
  answers1: Answers,
  answers2: Answers
): number {
  // Convert answers to type arrays
  const types1 = questions.map((q) => {
    const answer = answers1[q.id];
    const option = q.options.find((opt) => opt.id === answer);
    return option?.type || 2; // Default to type 2 if not found
  });

  const types2 = questions.map((q) => {
    const answer = answers2[q.id];
    const option = q.options.find((opt) => opt.id === answer);
    return option?.type || 2;
  });

  // Calculate total difference
  let totalDiff = 0;
  for (let i = 0; i < types1.length; i++) {
    totalDiff += Math.abs(types1[i] - types2[i]);
  }

  // Maximum possible difference is questions.length * 3
  const maxDiff = questions.length * 3;

  // Calculate score (0-100)
  const score = Math.round(100 - (totalDiff / maxDiff) * 100);

  return score;
}

// Find dominant type
export function findDominantType(answers1: Answers, answers2: Answers): number {
  const typeCounts: { [key: number]: number } = { 1: 0, 2: 0, 3: 0, 4: 0 };

  // Count types from both users
  questions.forEach((q) => {
    const answer1 = answers1[q.id];
    const option1 = q.options.find((opt) => opt.id === answer1);
    if (option1) typeCounts[option1.type]++;

    const answer2 = answers2[q.id];
    const option2 = q.options.find((opt) => opt.id === answer2);
    if (option2) typeCounts[option2.type]++;
  });

  // Find dominant type
  let dominantType = 2;
  let maxCount = 0;
  for (const [type, count] of Object.entries(typeCounts)) {
    if (count > maxCount) {
      maxCount = count;
      dominantType = parseInt(type);
    }
  }

  return dominantType;
}

// Hook for managing Reconnect Booth state
export function useReconnectManager() {
  const [currentSessionCode, setCurrentSessionCode] = useState<string | null>(
    null
  );
  const [currentSeat, setCurrentSeat] = useState<"1" | "2" | null>(null);
  const [answers, setAnswers] = useState<Answers>({});

  // Create new session (Seat 1)
  const createSession = (): string => {
    const code = generateSessionCode();
    setCurrentSessionCode(code);
    setCurrentSeat("1");
    setAnswers({});

    // Initialize session storage
    saveSession(code, {});

    return code;
  };

  // Join session (Seat 2)
  const joinSession = (code: string, seat1Answers?: Answers): boolean => {
    setCurrentSessionCode(code);
    setCurrentSeat("2");
    setAnswers({});

    // If seat1 answers provided, save them
    if (seat1Answers) {
      saveSession(code, { seat1: seat1Answers });
      return true;
    }

    // Otherwise check if seat1 exists
    const sessionData = loadSession(code);
    return !!sessionData?.seat1;
  };

  // Save answer
  const saveAnswer = (questionId: string, optionId: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: optionId,
    }));
  };

  // Complete session
  const completeSession = (): {
    seat1Answers: Answers | null;
    seat2Answers: Answers;
  } | null => {
    if (!currentSessionCode || !currentSeat) return null;

    const sessionData = loadSession(currentSessionCode);

    if (currentSeat === "1") {
      // Save seat 1 answers
      saveSession(currentSessionCode, {
        ...sessionData,
        seat1: answers,
      });
      return { seat1Answers: answers, seat2Answers: {} };
    } else {
      // Save seat 2 answers and return both
      saveSession(currentSessionCode, {
        ...sessionData,
        seat2: answers,
      });
      return {
        seat1Answers: sessionData?.seat1 || null,
        seat2Answers: answers,
      };
    }
  };

  // Reset session
  const resetSession = () => {
    setCurrentSessionCode(null);
    setCurrentSeat(null);
    setAnswers({});
  };

  // Get progress
  const getProgress = (): number => {
    return Object.keys(answers).length;
  };

  // Check if all questions answered
  const isComplete = (): boolean => {
    return Object.keys(answers).length === questions.length;
  };

  return {
    currentSessionCode,
    currentSeat,
    answers,
    createSession,
    joinSession,
    saveAnswer,
    completeSession,
    resetSession,
    getProgress,
    isComplete,
  };
}
