import { useEffect, useRef } from "react";

interface QRCodeGeneratorProps {
  text: string;
  size?: number;
}

export function QRCodeGenerator({ text, size = 220 }: QRCodeGeneratorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = size;
    canvas.height = size;

    // Clear canvas
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, size, size);

    // Generate pseudo-QR pattern (simplified visualization)
    const gridSize = 21; // Typical QR code module count
    const moduleSize = Math.floor(size / gridSize);
    const padding = (size - moduleSize * gridSize) / 2;

    // Simple hash function for deterministic pattern
    const hash = (str: string, seed: number) => {
      let h = seed;
      for (let i = 0; i < str.length; i++) {
        h = (h * 33) ^ str.charCodeAt(i);
      }
      return Math.abs(h);
    };

    // Draw modules
    ctx.fillStyle = "#000000";
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        // Position detection patterns (corners)
        const isFinderPattern =
          (row < 7 && col < 7) ||
          (row < 7 && col >= gridSize - 7) ||
          (row >= gridSize - 7 && col < 7);

        if (isFinderPattern) {
          // Draw finder pattern
          const inOuter =
            (row === 0 || row === 6 || col === 0 || col === 6) &&
            ((row < 7 && col < 7) ||
              (row < 7 && col >= gridSize - 7) ||
              (row >= gridSize - 7 && col < 7));
          const inInner =
            row >= 2 && row <= 4 && col >= 2 && col <= 4 && row < 7 && col < 7;
          const inInner2 =
            row >= 2 &&
            row <= 4 &&
            col >= gridSize - 5 &&
            col <= gridSize - 3 &&
            row < 7;
          const inInner3 =
            row >= gridSize - 5 &&
            row <= gridSize - 3 &&
            col >= 2 &&
            col <= 4 &&
            col < 7;

          if (inOuter || inInner || inInner2 || inInner3) {
            ctx.fillRect(
              padding + col * moduleSize,
              padding + row * moduleSize,
              moduleSize,
              moduleSize
            );
          }
        } else {
          // Generate pattern based on text hash
          const seed = hash(text, row * gridSize + col);
          if (seed % 2 === 0) {
            ctx.fillRect(
              padding + col * moduleSize,
              padding + row * moduleSize,
              moduleSize,
              moduleSize
            );
          }
        }
      }
    }

    // Add label
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(size * 0.25, size * 0.85, size * 0.5, size * 0.12);
    ctx.fillStyle = "#000000";
    ctx.font = `${size * 0.06}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("RECONNECT", size / 2, size * 0.91);
  }, [text, size]);

  return (
    <canvas
      ref={canvasRef}
      className="mx-auto border border-border rounded-lg"
    />
  );
}
