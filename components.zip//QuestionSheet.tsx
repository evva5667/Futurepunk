import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { QuestionCarousel } from "./QuestionCarousel";
import { type Answers } from "./ReconnectManager";
import { Button } from "./ui/button";
import { Home } from "lucide-react";

interface QuestionSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAnswer: (questionId: string, optionId: string) => void;
  answers: Answers;
  onComplete: () => void;
  currentSeat: "1" | "2" | null;
  sessionCode: string | null;
  onGoHome: () => void;
}

export function QuestionSheet({
  open,
  onOpenChange,
  onAnswer,
  answers,
  onComplete,
  currentSeat,
  sessionCode,
  onGoHome,
}: QuestionSheetProps) {
  if (!currentSeat || !sessionCode) return null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="h-[85vh] flex flex-col bg-background/95 backdrop-blur-xl"
      >
        <SheetHeader>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <SheetTitle>Seat {currentSeat}</SheetTitle>
              <SheetDescription className="mt-1">
                Answer these questions to discover your compatibility
              </SheetDescription>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-muted-foreground">
                Session: {sessionCode}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={onGoHome}
                className="gap-2"
              >
                <Home className="w-4 h-4" />
                Home
              </Button>
            </div>
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto py-6">
          <QuestionCarousel
            onAnswer={onAnswer}
            answers={answers}
            onComplete={onComplete}
            currentSeat={currentSeat}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
