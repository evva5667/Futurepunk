import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { QRCodeGenerator } from "./QRCodeGenerator";
import { Copy, QrCode, ExternalLink, Check, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface ResultSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  score: number;
  activities: string[];
  resultUrl: string;
  sessionCode: string;
  onDone: () => void;
}

export function ResultSheet({
  open,
  onOpenChange,
  score,
  activities,
  resultUrl,
  sessionCode,
  onDone,
}: ResultSheetProps) {
  const [showQR, setShowQR] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(resultUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenLink = () => {
    window.open(resultUrl, "_blank");
  };

  const isGoodMatch = score >= 55;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="h-[85vh] flex flex-col bg-background/95 backdrop-blur-xl"
      >
        <SheetHeader>
          <SheetTitle>Compatibility Result</SheetTitle>
          <SheetDescription>Session: {sessionCode}</SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto py-6">
          <div className="max-w-md mx-auto space-y-6">
            {/* Score Display */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", duration: 0.6 }}
              className="bg-gradient-to-br from-[#ffd7b0] to-[#fff2ea] rounded-2xl p-8 text-center shadow-lg"
            >
              <div className="relative inline-block">
                <motion.div
                  initial={{ rotate: -180, scale: 0 }}
                  animate={{ rotate: 0, scale: 1 }}
                  transition={{ type: "spring", duration: 0.8, delay: 0.2 }}
                  className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#ffb380] to-[#ff8a5b] flex items-center justify-center shadow-xl"
                >
                  <span className="text-5xl text-white">{score}%</span>
                </motion.div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5 }}
                  className="absolute -top-2 -right-2"
                >
                  <Sparkles className="w-8 h-8 text-[#ff8a5b]" />
                </motion.div>
              </div>

              <h3 className="mb-2 text-[#2e2a28]">
                Match score: <strong>{score}%</strong>
              </h3>
              <p className="text-[#6b6560]">
                {isGoodMatch
                  ? "Good match — consider connecting!"
                  : "Lower match — but everyone brings unique value!"}
              </p>
            </motion.div>

            {/* Activity Suggestions */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="bg-card border border-border rounded-xl p-6 space-y-3"
            >
              <h4 className="text-sm text-muted-foreground">
                Suggested activities:
              </h4>
              <ul className="space-y-2">
                {activities.map((activity, idx) => (
                  <motion.li
                    key={idx}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 + idx * 0.1 }}
                    className="flex items-start gap-2"
                  >
                    <span className="text-[#ff8a5b] mt-1">•</span>
                    <span>{activity}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            {/* Share Result */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="bg-card border border-border rounded-xl p-6 space-y-4"
            >
              <div>
                <h4 className="text-sm mb-2">Share this result</h4>
                <p className="text-xs text-muted-foreground mb-3">
                  Both people can open this link to view the result:
                </p>

                {/* Result URL */}
                <Input
                  value={resultUrl}
                  readOnly
                  className="mb-3 font-mono text-xs"
                  onClick={(e) => e.currentTarget.select()}
                />

                {/* Share Actions */}
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCopyLink}
                      variant="secondary"
                      size="sm"
                      className="flex-1"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Link
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={() => setShowQR(!showQR)}
                      variant="secondary"
                      size="sm"
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      {showQR ? "Hide QR" : "Show QR"}
                    </Button>
                    <Button
                      onClick={handleOpenLink}
                      variant="secondary"
                      size="sm"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* QR Code */}
                  <AnimatePresence>
                    {showQR && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="pt-4"
                      >
                        <QRCodeGenerator text={resultUrl} size={220} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>

            {/* Done Button */}
            <Button
              onClick={onDone}
              className="w-full bg-gradient-to-r from-[#ffb380] to-[#ff8a5b]"
              size="lg"
            >
              Done
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}