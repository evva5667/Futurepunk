// Question data structure for Reconnect Booth
// Each answer maps to a type (1-4) representing personality dimensions

export interface Answer {
  id: string;
  text: string;
  type: 1 | 2 | 3 | 4; // Type mapping for compatibility
}

export interface Question {
  id: string;
  title: string;
  answers: Answer[];
}

export const questions: Question[] = [
  {
    id: "q1",
    title: "Your ideal weekday evening involves...",
    answers: [
      { id: "q1a", text: "Reading or quiet hobby at home", type: 1 },
      { id: "q1b", text: "Dinner with close friends", type: 2 },
      { id: "q1c", text: "Trying a new restaurant or experience", type: 3 },
      { id: "q1d", text: "Community event or group activity", type: 4 },
    ],
  },
  {
    id: "q2",
    title: "When exploring a new city, you prefer to...",
    answers: [
      { id: "q2a", text: "Follow a detailed itinerary", type: 1 },
      { id: "q2b", text: "Mix planning with spontaneity", type: 2 },
      { id: "q2c", text: "Wander and discover spontaneously", type: 3 },
      { id: "q2d", text: "Join local tours and meet people", type: 4 },
    ],
  },
  {
    id: "q3",
    title: "Your approach to making decisions is...",
    answers: [
      { id: "q3a", text: "Careful analysis and research", type: 1 },
      { id: "q3b", text: "Balance logic and intuition", type: 2 },
      { id: "q3c", text: "Trust your gut feeling", type: 3 },
      { id: "q3d", text: "Discuss with others first", type: 4 },
    ],
  },
  {
    id: "q4",
    title: "At a social gathering, you're most likely to...",
    answers: [
      { id: "q4a", text: "Stay with one or two close friends", type: 1 },
      { id: "q4b", text: "Alternate between mingling and quiet moments", type: 2 },
      { id: "q4c", text: "Float around and meet new people", type: 3 },
      { id: "q4d", text: "Be in the center of the action", type: 4 },
    ],
  },
  {
    id: "q5",
    title: "Your ideal weekend project is...",
    answers: [
      { id: "q5a", text: "Organizing or improving your space", type: 1 },
      { id: "q5b", text: "Learning a practical new skill", type: 2 },
      { id: "q5c", text: "Starting a creative experiment", type: 3 },
      { id: "q5d", text: "Hosting or planning an event", type: 4 },
    ],
  },
  {
    id: "q6",
    title: "When facing a challenge, you tend to...",
    answers: [
      { id: "q6a", text: "Work through it methodically alone", type: 1 },
      { id: "q6b", text: "Seek advice then decide", type: 2 },
      { id: "q6c", text: "Try different creative solutions", type: 3 },
      { id: "q6d", text: "Brainstorm with a group", type: 4 },
    ],
  },
  {
    id: "q7",
    title: "Your comfort zone with routine is...",
    answers: [
      { id: "q7a", text: "Love stability and predictability", type: 1 },
      { id: "q7b", text: "Routine with occasional variety", type: 2 },
      { id: "q7c", text: "Prefer variety over routine", type: 3 },
      { id: "q7d", text: "Thrive on constant change", type: 4 },
    ],
  },
  {
    id: "q8",
    title: "Your communication style is best described as...",
    answers: [
      { id: "q8a", text: "Thoughtful and reserved", type: 1 },
      { id: "q8b", text: "Adaptable to the situation", type: 2 },
      { id: "q8c", text: "Expressive and animated", type: 3 },
      { id: "q8d", text: "Open and engaging with everyone", type: 4 },
    ],
  },
  {
    id: "q9",
    title: "When recharging, you prefer...",
    answers: [
      { id: "q9a", text: "Solitude and quiet activities", type: 1 },
      { id: "q9b", text: "Mix of alone time and small gatherings", type: 2 },
      { id: "q9c", text: "Active pursuits and new experiences", type: 3 },
      { id: "q9d", text: "Being around people and energy", type: 4 },
    ],
  },
  {
    id: "q10",
    title: "Your approach to trying new things is...",
    answers: [
      { id: "q10a", text: "Cautious, prefer the familiar", type: 1 },
      { id: "q10b", text: "Open but selective", type: 2 },
      { id: "q10c", text: "Eager to experiment", type: 3 },
      { id: "q10d", text: "Always ready for new adventures", type: 4 },
    ],
  },
];

// Activity suggestions based on dominant personality type
export const activitySuggestions = {
  1: [
    "Quiet café visit for deep conversation",
    "Museum or gallery exploration",
    "Bookstore browsing and coffee",
  ],
  2: [
    "Balanced mix: market stroll + café",
    "Cooking class or workshop together",
    "Scenic walk with conversation stops",
  ],
  3: [
    "Art/creative collaboration project",
    "City exploration and spontaneous finds",
    "Creative jam session or improv",
  ],
  4: [
    "Group activity or event together",
    "Social sports or active meetup",
    "Festival, concert, or bustling venue",
  ],
};
